import './App.css';

function App() {
  const doThing = (num) => {
    for(let i = 0; i < num; i++){
      console.log("you pressed the div!!!!");
    }
  }

  return (
    <>
      <div onClick={()=>{doThing(7)}} className="App">
        <marquee><h1>weeeeeeeeeeeeeeee!!</h1></marquee>
      </div>
      <h1 onMouseOver={()=>{console.log("you are moving the mous over the h1!!")}}>
        hello there!
      </h1>
    </>
  );
}

export default App;